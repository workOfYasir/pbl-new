<!DOCTYPE html>

<html lang="en">

<!-- Mirrored from html.codedthemes.com/mash-able/light/tabs.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 19 Sep 2019 14:09:10 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title>PBL | Department</title>


<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="description" content="#">
<meta name="keywords" content="Flat ui, Admin , Responsive, Landing, Bootstrap, App, Template, Mobile, iOS, Android, apple, creative app">
<meta name="author" content="#">

<link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">

<link rel="icon" href="../assets/images/favicon.ico" type="image/x-icon">

<link href="https://fonts.googleapis.com/css?family=Mada:300,400,500,600,700" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="../../bower_components/bootstrap/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="../assets/icon/themify-icons/themify-icons.css">

<link rel="stylesheet" type="text/css" href="../assets/icon/icofont/css/icofont.css">

<link rel="stylesheet" type="text/css" href="../assets/pages/flag-icon/flag-icon.min.css">

<link rel="stylesheet" type="text/css" href="../assets/pages/menu-search/css/component.css">

<link rel="stylesheet" type="text/css" href="../../bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" type="text/css" href="../assets/pages/data-table/css/buttons.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="../../bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">

<link rel="stylesheet" type="text/css" href="../assets/css/style.css">

<link rel="stylesheet" type="text/css" href="../assets/css/linearicons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/simple-line-icons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/ionicons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/jquery.mCustomScrollbar.css">

<link href="https://fonts.googleapis.com/css?family=Mada:300,400,500,600,700" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="../../bower_components/bootstrap/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="../assets/icon/themify-icons/themify-icons.css">

<link rel="stylesheet" type="text/css" href="../assets/icon/icofont/css/icofont.css">

<link rel="stylesheet" type="text/css" href="../assets/pages/flag-icon/flag-icon.min.css">

<link rel="stylesheet" type="text/css" href="../assets/pages/menu-search/css/component.css">

<link rel="stylesheet" type="text/css" href="../assets/pages/j-pro/css/demo.css">
<link rel="stylesheet" type="text/css" href="../assets/pages/j-pro/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../assets/pages/j-pro/css/j-pro-modern.css">

<link rel="stylesheet" type="text/css" href="../assets/css/style.css">

<link rel="stylesheet" type="text/css" href="../assets/css/linearicons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/simple-line-icons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/ionicons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/jquery.mCustomScrollbar.css">

<link href="https://fonts.googleapis.com/css?family=Mada:300,400,500,600,700" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="../../bower_components/bootstrap/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="../assets/icon/themify-icons/themify-icons.css">

<link rel="stylesheet" type="text/css" href="../assets/icon/icofont/css/icofont.css">

<link rel="stylesheet" type="text/css" href="../assets/pages/flag-icon/flag-icon.min.css">

<link rel="stylesheet" type="text/css" href="../assets/pages/menu-search/css/component.css">

<link rel="stylesheet" type="text/css" href="../assets/css/style.css">

<link rel="stylesheet" type="text/css" href="../assets/css/linearicons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/simple-line-icons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/ionicons.css">
<link rel="stylesheet" type="text/css" href="../assets/css/jquery.mCustomScrollbar.css">
<?php include("../links.php"); ?>

<div class="theme-loader">
<div class="ball-scale">
<div></div>
</div>
</div>

<div id="pcoded" class="pcoded">
<div class="pcoded-overlay-box"></div>
<div class="pcoded-container navbar-wrapper">


<?php


include 'admin-header.php';

?>



 

<div class="pcoded-main-container">
<div class="pcoded-wrapper">
 
 
 <?php



   include 'manager-nav.php';


?>


 
 
<div class="pcoded-content">
<div class="pcoded-inner-content">

<div class="main-body">
<div class="page-wrapper">

 


 
 
 
<div class="row">
<div class="col-sm-12">

<div class="card">
<div class="card-header">
<h5>Manage Department</h5>
<div class="card-header-right">
<i class="icofont icofont-rounded-down"></i>
<i class="icofont icofont-refresh"></i>
 
</div>
</div>
<div class="card-block tab-icon">

<div class="row">
<div class="col-lg-12 col-xl-12">

 

<ul class="nav nav-tabs md-tabs " role="tablist">
<li class="nav-item">
<a class="nav-link active" data-toggle="tab" href="#home7" role="tab"><i class="icofont icofont-home"></i>Add New Department </a>
<div class="slide"></div>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#profile7" role="tab"><i class="icofont icofont-ui-user "></i>View All Department</a>
<div class="slide"></div>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#messages7" role="tab"><i class="icofont icofont-ui-message"></i>View Recycle Department</a>
<div class="slide"></div>
</li>
 
</ul>

<div class="tab-content card-block">


<div class="tab-pane active" id="home7" role="tabpanel">


 

 
<div class="j-wrapper j-wrapper-640" style="margin-top:-30px;">
<form action="saveDept.php" method="post" class="j-pro" id="j-pro" enctype="multipart/form-data" novalidate  >

<div class="j-content">

<div class="j-row">
<div class="j-span6 j-unit">
<div class="j-input">
<label class="j-icon-right" for="first_name">
<i class="icofont icofont-ui-user"></i>
</label>
<input type="name" id="first_name" name="first_name" placeholder="Department Name">
 </div>
</div>
<div class="j-span6 j-unit">
<div class="j-input">
<label class="j-icon-right" for="last_name">
<i class="icofont icofont-ui-user"></i>
</label>
<input type="code" id="last_name" name="last_name" placeholder="Degree Code">
</div>
</div>
</div>

 
 



 

<div class="divider gap-bottom-25"></div>

 
 

 

<div class="j-response"></div>

</div>

<div class="j-footer">
<button type="submit" class="btn btn-primary">Send</button>
<button type="reset" class="btn btn-default m-r-20">Reset</button>
 </div>

</form>
</div>
 
 


</div>






<div class="tab-pane" id="profile7" role="tabpanel">
 
<table id="simpletable" class="table table-striped table-bordered nowrap">
<thead>
<tr>
<th>Name</th>
<th>Position</th>
<th>Office</th>
<th>Age</th>
<th>Start date</th>
<th>Salary</th>
</tr>
</thead>
<tbody>
<tr>
<td>System Architect</td>
<td>Edinburgh</td>
 <td>61</td>
<td>2011/04/25</td>
<td>$320,800</td>
<td>Tiger Nixon</td>
</tr>
<tr>
<td>Garrett Winters</td>
<td>Accountant</td>
<td>Tokyo</td>
<td>63</td>
<td>2011/07/25</td>
<td>$170,750</td>
</tr>
<tr>
<td>Ashton Cox</td>
<td>Junior Technical Author</td>
<td>San Francisco</td>
<td>66</td>
<td>2009/01/12</td>
<td>$86,000</td>
</tr>
<tr>
<td>Cedric Kelly</td>
<td>Senior Javascript Developer</td>
<td>Edinburgh</td>
<td>22</td>
<td>2012/03/29</td>
<td>$433,060</td>
</tr>
 
</tfoot>
</table>
 
</div>
 
 
</div>
</div>
 
</div>

</div>
</div>

</div>
</div>
 

</div>
</div>

<div id="styleSelector">
</div>
</div>
</div>
</div>
</div>
</div>
</div>


<!--[if lt IE 9]>
<div class="ie-warning">
    <h1>Warning!!</h1>
    <p>You are using an outdated version of Internet Explorer, please upgrade <br/>to any of the following web browsers to access this website.</p>
    <div class="iew-container">
        <ul class="iew-download">
            <li>
                <a href="http://www.google.com/chrome/">
                    <img src="../assets/images/browser/chrome.png" alt="Chrome">
                    <div>Chrome</div>
                </a>
            </li>
            <li>
                <a href="https://www.mozilla.org/en-US/firefox/new/">
                    <img src="../assets/images/browser/firefox.png" alt="Firefox">
                    <div>Firefox</div>
                </a>
            </li>
            <li>
                <a href="http://www.opera.com">
                    <img src="../assets/images/browser/opera.png" alt="Opera">
                    <div>Opera</div>
                </a>
            </li>
            <li>
                <a href="https://www.apple.com/safari/">
                    <img src="../assets/images/browser/safari.png" alt="Safari">
                    <div>Safari</div>
                </a>
            </li>
            <li>
                <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                    <img src="../assets/images/browser/ie.png" alt="">
                    <div>IE (9 & above)</div>
                </a>
            </li>
        </ul>
    </div>
    <p>Sorry for the inconvenience!</p>
</div>
<![endif]-->


<script type="text/javascript" src="../../bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="../../bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="../../bower_components/bootstrap/js/bootstrap.min.js"></script>

<script type="text/javascript" src="../../bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>

<script type="text/javascript" src="../../bower_components/modernizr/js/modernizr.js"></script>
<script type="text/javascript" src="../../bower_components/modernizr/js/css-scrollbars.js"></script>

<script type="text/javascript" src="../../bower_components/classie/js/classie.js"></script>

<script type="text/javascript" src="../../bower_components/i18next/js/i18next.min.js"></script>
<script type="text/javascript" src="../../bower_components/i18next-xhr-backend/js/i18nextXHRBackend.min.js"></script>
<script type="text/javascript" src="../../bower_components/i18next-browser-languagedetector/js/i18nextBrowserLanguageDetector.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery-i18next/js/jquery-i18next.min.js"></script>

<script type="text/javascript" src="../assets/js/script.js"></script>
<script src="../assets/js/pcoded.min.js"></script>
<script src="../assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="../assets/js/jquery.mousewheel.min.js"></script>
<script src="../assets/js/demo-12.js"></script>

<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="text/javascript" src="../../bower_components/jquery/js/jquery.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery-ui/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="../../bower_components/popper.js/js/popper.min.js"></script>
<script type="text/javascript" src="../../bower_components/bootstrap/js/bootstrap.min.js"></script>

<script type="text/javascript" src="../../bower_components/jquery-slimscroll/js/jquery.slimscroll.js"></script>

<script type="text/javascript" src="../../bower_components/modernizr/js/modernizr.js"></script>
<script type="text/javascript" src="../../bower_components/modernizr/js/css-scrollbars.js"></script>

<script type="text/javascript" src="../../bower_components/classie/js/classie.js"></script>

<script src="../../bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="../../bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="../assets/pages/data-table/js/jszip.min.js"></script>
<script src="../assets/pages/data-table/js/pdfmake.min.js"></script>
<script src="../assets/pages/data-table/js/vfs_fonts.js"></script>
<script src="../../bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="../../bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="../../bower_components/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../bower_components/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../bower_components/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript" src="../../bower_components/i18next/js/i18next.min.js"></script>
<script type="text/javascript" src="../../bower_components/i18next-xhr-backend/js/i18nextXHRBackend.min.js"></script>
<script type="text/javascript" src="../../bower_components/i18next-browser-languagedetector/js/i18nextBrowserLanguageDetector.min.js"></script>
<script type="text/javascript" src="../../bower_components/jquery-i18next/js/jquery-i18next.min.js"></script>

<script src="../assets/pages/data-table/js/data-table-custom.js"></script>
<script type="text/javascript" src="../assets/js/script.js"></script>
<script src="../assets/js/pcoded.min.js"></script>
<script src="../assets/js/demo-12.js"></script>
<script src="../assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="../assets/js/jquery.mousewheel.min.js"></script>
<?php include("../scripts.php"); ?>