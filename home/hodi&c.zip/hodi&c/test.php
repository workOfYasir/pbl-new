<?php 

$test=$_GET['course'];
$test1=$_GET['depart'];
echo $test.'+Heeo'. $test1;
?>