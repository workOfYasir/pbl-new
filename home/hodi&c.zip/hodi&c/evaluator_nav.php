
<nav class="pcoded-navbar">
<div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
<div class="pcoded-inner-navbar main-menu">
<div class="pcoded-navigatio-lavel" data-i18n="nav.category.navigation">Navigation</div>
<ul class="pcoded-item pcoded-left-item">
<li>
<a href="evaluator-index.php">
<span class="pcoded-micon"><i class="ti-home"></i></span>
<span class="pcoded-mtext" data-i18n="nav.animations.main"> Dashboard</span>
<span class="pcoded-mcaret"></span>
</a>
</li>
<li>
<a href="add-meeting.php">
<span class="pcoded-micon"><i class="ti-home"></i></span>
<span class="pcoded-mtext" data-i18n="nav.animations.main"> Meeting</span>
<span class="pcoded-mcaret"></span>
</a>
</li>


 
 
 
 




  
 
  



 

 

</ul>





</div>
</nav>
