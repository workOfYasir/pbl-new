<nav class="pcoded-navbar" style="position: absolute !important ;">
<div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
<div class="pcoded-inner-navbar main-menu">
<div class="pcoded-navigatio-lavel" data-i18n="nav.category.navigation">Navigation</div>
<ul class="pcoded-item pcoded-left-item">
<li class="pcoded-hasmenu active pcoded-trigger">
<a href="admin-index.php">
<span class="pcoded-micon"><i class="ti-home"></i></span>
<span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
<span class="pcoded-mcaret"></span>
</a>
 
</li>
<li class=" ">
<a href="teachers.php" data-i18n="nav.animations.main">
<span class="pcoded-micon"><i class="ti-reload rotate-refresh"></i></span>
<span class="pcoded-mtext">Manage Teachers</span>
<span class="pcoded-mcaret"></span>
</a>
</li>
<li class=" ">
<a href="projects.php" data-i18n="nav.animations.main">
<span class="pcoded-micon"><i class="ti-reload rotate-refresh"></i></span>
<span class="pcoded-mtext">Manage Projects</span>
<span class="pcoded-mcaret"></span>
</a>
</li>
<li class=" ">
<a href="courses.php" data-i18n="nav.animations.main">
<span class="pcoded-micon"><i class="ti-reload rotate-refresh"></i></span>
<span class="pcoded-mtext">Manage Courses</span>
<span class="pcoded-mcaret"></span>
</a>
</li>
 <li class=" ">
<a href="dept.php" data-i18n="nav.animations.main">
<span class="pcoded-micon"><i class="ti-reload rotate-refresh"></i></span>
<span class="pcoded-mtext">Manage Departments</span>
<span class="pcoded-mcaret"></span>
</a>
</li>
 <li class=" ">
<a href="students.php" data-i18n="nav.animations.main">
<span class="pcoded-micon"><i class="ti-reload rotate-refresh"></i></span>
<span class="pcoded-mtext">Manage Students</span>
<span class="pcoded-mcaret"></span>
</a>
</li>
 
 
</ul>
</div>
</nav>